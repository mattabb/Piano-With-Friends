module.exports = {
  transpileDependencies: ["vuetify"]
};
